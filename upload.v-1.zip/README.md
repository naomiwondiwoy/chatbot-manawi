# password

// $hashed = password_hash("admin123", PASSWORD_BCRYPT);
// echo $hashed;

$2y$10$.wDqiT6t3otRHkYMyqD3RO0dISmY4ab4HMbS8nG20LxP0AZE1qaYG

INSERT INTO users (username, password) VALUES ('admin', '$2y$10$.wDqiT6t3otRHkYMyqD3RO0dISmY4ab4HMbS8nG20LxP0AZE1qaYG');


# git commands

perintah untuk tambah perubahan ke git repsitory 

```
git add .
```

perintah untuk melakukan commit
```
git commit
```

perintah untuk upload perubahan ke git remote di internet
```
git push
```

perintah untuk mengambil perubahan dari git remote di internet
```
git pull
```

# buat database

# buat tabel

## DB Online

sakodeko_menawichatbot
sakodeko_menawichatbot
sakodeko_menawichatbot